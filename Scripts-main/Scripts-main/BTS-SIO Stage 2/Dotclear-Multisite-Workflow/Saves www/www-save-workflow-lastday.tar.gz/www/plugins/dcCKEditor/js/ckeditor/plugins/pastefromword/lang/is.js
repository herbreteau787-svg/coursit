
﻿
CKEDITOR.plugins.setLang('pastefromword','is',{confirmCleanup:'The text you want to paste seems to be copied from Word. Do you want to clean it before pasting?',error:'It was not possible to clean up the pasted data due to an internal error',title:'Líma úr Word',toolbar:'Líma úr Word'});