
﻿
CKEDITOR.plugins.setLang('specialchar','gu',{options:'સ્પેશિઅલ કરેક્ટરના વિકલ્પો',title:'સ્પેશિઅલ વિશિષ્ટ અક્ષર પસંદ કરો',toolbar:'વિશિષ્ટ અક્ષર ઇન્સર્ટ/દાખલ કરવું'});